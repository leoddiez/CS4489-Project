"""Print an admin account's current 6-digit TOTP code (for testing the MFA login).

Usage:  python scripts/mfa_code.py [username]   (default: alphaadmin)
Reads the secret from the defended database as the Postgres superuser.
"""
import os
import sys
import time
import hmac
import struct
import base64
import hashlib

import psycopg

username = sys.argv[1] if len(sys.argv) > 1 else "alphaadmin"

conn = psycopg.connect(
    host=os.getenv("DB_HOST", "db"),
    port=os.getenv("DB_PORT", "5432"),
    dbname="defended_db",
    user=os.getenv("DB_SUPERUSER", "postgres"),
    password=os.getenv("DB_SUPERPASS", "postgres"),
    sslmode=os.getenv("DB_SSLMODE", "prefer"),
)
cur = conn.cursor()
cur.execute("SELECT totp_secret FROM users WHERE username = %s", (username,))
row = cur.fetchone()
cur.close()
conn.close()

if not row or not row[0]:
    sys.exit(f"No TOTP secret for '{username}' (only admin accounts have one).")

secret = row[0]
counter = int(time.time() // 30)
digest = hmac.new(base64.b32decode(secret, casefold=True),
                  struct.pack(">Q", counter), hashlib.sha1).digest()
offset = digest[-1] & 0x0F
code = struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF
print(str(code % 1000000).zfill(6))
