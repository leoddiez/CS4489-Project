#!/usr/bin/env bash
# Start both backends: vulnerable on 8001, defended on 8002.
set -e
cd "$(dirname "$0")/.."
# shellcheck disable=SC1091
source .venv/bin/activate 2>/dev/null || true

echo "Vulnerable backend -> http://localhost:8001   (docs: /docs)"
( cd backend-vulnerable && exec python -m uvicorn main:app --host 0.0.0.0 --port 8001 ) &
VULN_PID=$!

echo "Defended backend   -> http://localhost:8002   (docs: /docs)"
( cd backend-defended && exec python -m uvicorn main:app --host 0.0.0.0 --port 8002 ) &
DEF_PID=$!

trap 'kill $VULN_PID $DEF_PID 2>/dev/null' INT TERM
wait
