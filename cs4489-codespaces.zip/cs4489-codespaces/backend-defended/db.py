import os
import psycopg
from dotenv import load_dotenv

load_dotenv()


def get_connection():
    """Connect as the least-privilege application role over TLS when available."""
    return psycopg.connect(
        host=os.getenv("DB_HOST"),
        port=os.getenv("DB_PORT", "5432"),
        dbname=os.getenv("DB_NAME"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        sslmode=os.getenv("DB_SSLMODE", "require"),
    )


def set_tenant(cursor, tenant_id: int):
    """Bind the DB session to a tenant so Row-Level Security filters every query.

    Uses set_config with a parameter (not string formatting) so the tenant id
    cannot break out of the statement.
    """
    cursor.execute(
        "SELECT set_config('app.current_tenant', %s, true)", (str(int(tenant_id)),)
    )
