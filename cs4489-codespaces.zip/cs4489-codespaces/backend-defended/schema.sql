-- Defended schema: same structure as the vulnerable app, plus Row-Level
-- Security, a least-privilege grant, an audit log, and columns for lockout
-- and the admin TOTP secret. Run as the table owner (def_owner).

CREATE TABLE IF NOT EXISTS tenants (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    tenant_id INTEGER NOT NULL REFERENCES tenants(id),
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,          -- Argon2id hash
    role VARCHAR(30) NOT NULL DEFAULT 'user',
    failed_logins INTEGER NOT NULL DEFAULT 0,
    locked_until TIMESTAMPTZ,
    totp_secret VARCHAR(64)                   -- base32 TOTP secret (admins)
);

CREATE TABLE IF NOT EXISTS customers (
    id SERIAL PRIMARY KEY,
    tenant_id INTEGER NOT NULL REFERENCES tenants(id),
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE,
    phone VARCHAR(30),
    ssn_last4 VARCHAR(4)
);

CREATE TABLE IF NOT EXISTS audit_log (
    id BIGSERIAL PRIMARY KEY,
    ts TIMESTAMPTZ NOT NULL DEFAULT now(),
    actor VARCHAR(50),
    tenant_id INTEGER,
    action VARCHAR(60) NOT NULL,
    detail TEXT
);

INSERT INTO tenants (id, name) VALUES (1, 'Alpha Health'), (2, 'Beta Health')
ON CONFLICT DO NOTHING;
SELECT setval('tenants_id_seq', (SELECT MAX(id) FROM tenants));

INSERT INTO customers (tenant_id, full_name, email, phone, ssn_last4) VALUES
    (1, 'Alice Johnson', 'alice.johnson@example.test', '555-111-1111', '1234'),
    (1, 'Bob Smith',     'bob.smith@example.test',     '555-222-2222', '5678'),
    (2, 'Charlie Lee',   'charlie.lee@example.test',   '555-333-3333', '9012'),
    (2, 'Diana Brown',   'diana.brown@example.test',   '555-444-4444', '3456')
ON CONFLICT (email) DO NOTHING;

-- ===================== Row-Level Security =====================
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation ON customers;
CREATE POLICY tenant_isolation ON customers
    USING (tenant_id = current_setting('app.current_tenant', true)::int);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE users FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS users_self ON users;
CREATE POLICY users_self ON users USING (true);

-- ===================== Least privilege for def_app =====================
GRANT USAGE ON SCHEMA public TO def_app;
GRANT SELECT, INSERT, UPDATE ON customers TO def_app;
GRANT SELECT, UPDATE ON users TO def_app;
GRANT SELECT ON tenants TO def_app;
GRANT INSERT ON audit_log TO def_app;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO def_app;
-- Intentionally NO DELETE and NO DDL privileges.
