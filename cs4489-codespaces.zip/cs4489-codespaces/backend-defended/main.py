"""
CS4489 Defended Backend.

Same endpoints and JSON shapes as the vulnerable backend, hardened with
defense-in-depth controls:

  1. Parameterized SQL everywhere (no string-built queries).
  2. Argon2id password verification (no plaintext passwords stored or returned).
  3. Uniform authentication errors (no username enumeration).
  4. Minimal response payloads (no password / internal fields leaked).
  5. Generic 500s (no raw database errors leaked to the client).
  6. Signed, expiring session tokens; server derives tenant from the token
     instead of trusting a client-supplied tenant_id.
  7. PostgreSQL Row-Level Security + least-privilege DB role as a second,
     independent enforcement layer for tenant isolation.
  8. Function-level authorization on the admin endpoint.
  9. Per-IP login rate limiting + account lockout.
 10. Sensitive-field masking (ssn_last4) for non-admin roles.
 11. Append-only audit log for security monitoring.
"""

import os
import time
import hmac
import json
import base64
import hashlib
import secrets
from collections import defaultdict

from fastapi import FastAPI, HTTPException, Depends, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from pwdlib import PasswordHash

from db import get_connection, set_tenant

hasher = PasswordHash.recommended()

# Session-signing secret. In production this comes from Key Vault / env; we
# generate one per process so tokens cannot be forged without it.
SECRET_KEY = os.getenv("SESSION_SECRET", secrets.token_hex(32)).encode()
TOKEN_TTL_SECONDS = 1800

app = FastAPI(
    title="CS4489 Defended Backend",
    description="Hardened backend demonstrating defense in depth.",
    version="1.0.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://8tes.org", "http://localhost:8080"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "PATCH"],
    allow_headers=["Content-Type", "Authorization"],
)


# --------------------------------------------------------------------------
# Signed token helpers (stateless, HMAC-SHA256, no third-party dependency)
# --------------------------------------------------------------------------
def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def _unb64(data: str) -> bytes:
    return base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))


def issue_token(user_id: int, tenant_id: int, role: str) -> str:
    payload = {
        "uid": user_id,
        "tid": tenant_id,
        "role": role,
        "exp": int(time.time()) + TOKEN_TTL_SECONDS,
    }
    body = _b64(json.dumps(payload, separators=(",", ":")).encode())
    sig = _b64(hmac.new(SECRET_KEY, body.encode(), hashlib.sha256).digest())
    return f"{body}.{sig}"


def verify_token(token: str) -> dict:
    try:
        body, sig = token.split(".")
    except ValueError:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    expected = _b64(hmac.new(SECRET_KEY, body.encode(), hashlib.sha256).digest())
    if not hmac.compare_digest(sig, expected):
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    payload = json.loads(_unb64(body))
    if payload.get("exp", 0) < int(time.time()):
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    return payload


def current_user(authorization: str = Header(default="")) -> dict:
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Authentication required")
    return verify_token(authorization[7:])


# --------------------------------------------------------------------------
# Lightweight in-process rate limiting / lockout
# --------------------------------------------------------------------------
_login_attempts = defaultdict(list)       # ip -> [timestamps]
RATE_WINDOW = 60
RATE_MAX = int(os.getenv("RATE_MAX", "10"))


def rate_limit(request: Request):
    ip = request.client.host if request.client else "unknown"
    now = time.time()
    hits = [t for t in _login_attempts[ip] if now - t < RATE_WINDOW]
    hits.append(now)
    _login_attempts[ip] = hits
    if len(hits) > RATE_MAX:
        raise HTTPException(status_code=429, detail="Too many attempts. Try again later.")


def audit(cursor, actor, tenant_id, action, detail=""):
    cursor.execute(
        "INSERT INTO audit_log (actor, tenant_id, action, detail) VALUES (%s,%s,%s,%s)",
        (actor, tenant_id, action, detail[:500]),
    )


def mask_ssn(value, role):
    if value is None:
        return None
    return value if role == "admin" else "****"


# --------------------------------------------------------------------------
# TOTP second factor (RFC 6238), required for admin accounts
# --------------------------------------------------------------------------
import struct


def _totp_at(secret_b32: str, moment: float, step: int = 30, digits: int = 6) -> str:
    counter = int(moment // step)
    key = base64.b32decode(secret_b32, casefold=True)
    digest = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    code = struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF
    return str(code % (10 ** digits)).zfill(digits)


def totp_now(secret_b32: str) -> str:
    """The current 6-digit code (used to drive the demo client)."""
    return _totp_at(secret_b32, time.time())


def totp_verify(secret_b32: str, code: str, window: int = 1) -> bool:
    if not code or not code.isdigit():
        return False
    now = time.time()
    # Accept the current step and +/- one step to tolerate clock skew.
    for w in range(-window, window + 1):
        if hmac.compare_digest(_totp_at(secret_b32, now + w * 30), code):
            return True
    return False


# --------------------------------------------------------------------------
# Models
# --------------------------------------------------------------------------
class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=50)
    password: str = Field(min_length=1, max_length=200)
    totp: str | None = Field(default=None, max_length=10)


class PhoneUpdate(BaseModel):
    phone: str = Field(min_length=7, max_length=30, pattern=r"^[0-9+\-() .]+$")


# --------------------------------------------------------------------------
# Health
# --------------------------------------------------------------------------
@app.get("/")
def root():
    return {"message": "CS4489 Defended Backend is running"}


@app.get("/health")
def health():
    return {"status": "healthy"}


@app.get("/db-health")
def database_health():
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT 1;")
        cur.fetchone()
        cur.close()
        conn.close()
        return {"database": "connected"}
    except Exception:
        # No internal detail leaked.
        raise HTTPException(status_code=503, detail="Database unavailable")


# --------------------------------------------------------------------------
# Authentication
# --------------------------------------------------------------------------
@app.post("/auth/login")
def login(data: LoginRequest, request: Request):
    rate_limit(request)
    conn = cur = None
    try:
        conn = get_connection()
        cur = conn.cursor()

        # Parameterized lookup. Fetch the stored hash + lock state.
        cur.execute(
            "SELECT id, tenant_id, username, password, role, failed_logins, "
            "locked_until, totp_secret FROM users WHERE username = %s LIMIT 1",
            (data.username,),
        )
        row = cur.fetchone()

        # Uniform response whether or not the username exists, and always
        # pay the hashing cost to avoid a timing oracle.
        if row is None:
            hasher.hash(data.password)  # dummy work
            raise HTTPException(status_code=401, detail="Invalid username or password")

        uid, tid, uname, stored_hash, role, failed, locked_until, totp_secret = row

        if locked_until is not None:
            cur.execute("SELECT now() < %s", (locked_until,))
            if cur.fetchone()[0]:
                audit(cur, uname, tid, "LOGIN_LOCKED")
                conn.commit()
                raise HTTPException(status_code=423, detail="Account temporarily locked")

        if not hasher.verify(data.password, stored_hash):
            new_failed = failed + 1
            if new_failed >= 5:
                cur.execute(
                    "UPDATE users SET failed_logins=%s, locked_until=now()+interval '15 minutes' WHERE id=%s",
                    (new_failed, uid),
                )
            else:
                cur.execute("UPDATE users SET failed_logins=%s WHERE id=%s", (new_failed, uid))
            audit(cur, uname, tid, "LOGIN_FAIL")
            conn.commit()
            raise HTTPException(status_code=401, detail="Invalid username or password")

        # Second factor: admin accounts must present a valid TOTP code.
        if role == "admin" and totp_secret:
            if not data.totp:
                audit(cur, uname, tid, "MFA_REQUIRED")
                conn.commit()
                raise HTTPException(
                    status_code=401,
                    detail={"message": "Second factor required", "mfa_required": True},
                )
            if not totp_verify(totp_secret, data.totp):
                new_failed = failed + 1
                cur.execute("UPDATE users SET failed_logins=%s WHERE id=%s", (new_failed, uid))
                audit(cur, uname, tid, "MFA_FAIL")
                conn.commit()
                raise HTTPException(status_code=401, detail="Invalid second factor")

        # Success: reset counters, issue signed token, log.
        cur.execute("UPDATE users SET failed_logins=0, locked_until=NULL WHERE id=%s", (uid,))
        audit(cur, uname, tid, "LOGIN_OK")
        conn.commit()

        token = issue_token(uid, tid, role)
        return {
            "message": "Login successful",
            "token": token,
            "user_id": uid,
            "tenant_id": tid,
            "username": uname,
            "role": role,
        }
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Internal server error")
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()


# --------------------------------------------------------------------------
# Customers — tenant derived from token, enforced again by RLS
# --------------------------------------------------------------------------
@app.get("/api/customers")
def my_customers(user: dict = Depends(current_user)):
    conn = cur = None
    try:
        conn = get_connection()
        cur = conn.cursor()
        set_tenant(cur, user["tid"])  # RLS will filter to this tenant
        cur.execute(
            "SELECT id, full_name, email, phone, ssn_last4 FROM customers ORDER BY id"
        )
        rows = cur.fetchall()
        customers = [
            {
                "id": r[0],
                "full_name": r[1],
                "email": r[2],
                "phone": r[3],
                "ssn_last4": mask_ssn(r[4], user["role"]),
            }
            for r in rows
        ]
        return {"tenant_id": user["tid"], "customers": customers}
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Internal server error")
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()


@app.get("/api/admin/tenant-report")
def admin_tenant_report(user: dict = Depends(current_user)):
    # Function-level authorization.
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Administrator access required")
    conn = cur = None
    try:
        conn = get_connection()
        cur = conn.cursor()
        # Admin report is cross-tenant by design; run it with RLS bypassed only
        # for the aggregate counts, via a SECURITY-checked explicit query that
        # never exposes row data. Tenant set to the admin's own for audit.
        set_tenant(cur, user["tid"])
        cur.execute(
            "SELECT t.id, t.name, "
            "(SELECT COUNT(*) FROM customers c WHERE c.tenant_id=t.id), "
            "(SELECT COUNT(*) FROM users u WHERE u.tenant_id=t.id) "
            "FROM tenants t ORDER BY t.id"
        )
        rows = cur.fetchall()
        audit(cur, user["uid"], user["tid"], "ADMIN_REPORT")
        conn.commit()
        companies = [
            {"tenant_id": r[0], "company": r[1], "customer_count": r[2], "user_count": r[3]}
            for r in rows
        ]
        return {"report": "Tenant Administration Summary", "companies": companies}
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Internal server error")
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()


@app.patch("/api/customers/{customer_id}/phone")
def update_customer_phone(customer_id: int, data: PhoneUpdate, user: dict = Depends(current_user)):
    conn = cur = None
    try:
        conn = get_connection()
        cur = conn.cursor()
        set_tenant(cur, user["tid"])  # RLS blocks cross-tenant writes
        cur.execute(
            "UPDATE customers SET phone=%s WHERE id=%s "
            "RETURNING id, tenant_id, full_name, phone",
            (data.phone, customer_id),
        )
        updated = cur.fetchone()
        if updated is None:
            conn.rollback()
            # Either not found or not in caller's tenant -> same 404.
            raise HTTPException(status_code=404, detail="Customer not found")
        audit(cur, user["uid"], user["tid"], "PHONE_UPDATE", f"customer={customer_id}")
        conn.commit()
        return {
            "message": "Customer updated successfully",
            "customer": {
                "id": updated[0],
                "tenant_id": updated[1],
                "full_name": updated[2],
                "phone": updated[3],
            },
        }
    except HTTPException:
        raise
    except Exception:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=500, detail="Internal server error")
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()
