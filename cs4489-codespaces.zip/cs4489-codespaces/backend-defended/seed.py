"""
Seed the defended database with Argon2id-hashed user passwords and TOTP
secrets for the admin accounts. Runs as the Postgres superuser so it can write
through Row-Level Security during provisioning.

Connection comes from environment variables (set by .devcontainer/setup.sh):
    DB_HOST (default 127.0.0.1), DB_SUPERUSER (default postgres),
    DB_SUPERPASS (default postgres), DB_SSLMODE (default prefer)
"""
import os
import base64
import secrets

import psycopg
from pwdlib import PasswordHash

hasher = PasswordHash.recommended()

conn = psycopg.connect(
    host=os.getenv("DB_HOST", "127.0.0.1"),
    port=os.getenv("DB_PORT", "5432"),
    dbname="defended_db",
    user=os.getenv("DB_SUPERUSER", "postgres"),
    password=os.getenv("DB_SUPERPASS", "postgres"),
    sslmode=os.getenv("DB_SSLMODE", "prefer"),
)
conn.autocommit = True
cur = conn.cursor()

users = [
    (1, "alice",      "alice123",   "user"),
    (1, "alphaadmin", "alpha123",   "admin"),
    (2, "charlie",    "charlie123", "user"),
    (2, "betaadmin",  "beta123",    "admin"),
]
for tid, uname, pw, role in users:
    cur.execute(
        "INSERT INTO users (tenant_id, username, password, role) "
        "VALUES (%s, %s, %s, %s) "
        "ON CONFLICT (username) DO UPDATE SET password = EXCLUDED.password, role = EXCLUDED.role",
        (tid, uname, hasher.hash(pw), role),
    )

print("Users seeded with Argon2id password hashes.")
print("\nAdmin MFA (TOTP) secrets — add these to an authenticator app:")
for admin in ("alphaadmin", "betaadmin"):
    secret = base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")
    cur.execute("UPDATE users SET totp_secret = %s WHERE username = %s", (secret, admin))
    uri = f"otpauth://totp/CS4489:{admin}?secret={secret}&issuer=CS4489"
    print(f"  {admin}: {secret}")
    print(f"           {uri}")

cur.close()
conn.close()
print("\nSeed complete. Use scripts/mfa_code.py to print an admin's current code for testing.")
