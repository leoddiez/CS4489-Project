#!/usr/bin/env bash
# Runs once when the Codespace is created. Installs deps, waits for Postgres,
# creates both databases + the least-privilege role, writes .env files, and
# seeds the vulnerable and defended schemas.
set -euo pipefail
cd "$(dirname "$0")/.."   # repo root (/workspace)

echo "==> Installing PostgreSQL client"
sudo apt-get update -y >/dev/null
sudo apt-get install -y postgresql-client >/dev/null

echo "==> Creating Python virtual environment and installing dependencies"
python -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
pip install --upgrade pip >/dev/null
pip install -r backend-vulnerable/requirements.txt
pip install -r backend-defended/requirements.txt

export PGPASSWORD=postgres
echo "==> Waiting for PostgreSQL to accept connections"
until pg_isready -h db -U postgres >/dev/null 2>&1; do sleep 1; done

echo "==> Creating roles and databases"
psql -h db -U postgres -v ON_ERROR_STOP=1 <<'SQL'
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='def_owner') THEN
    CREATE ROLE def_owner LOGIN PASSWORD 'def_owner_pw';
  END IF;
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='def_app') THEN
    CREATE ROLE def_app LOGIN PASSWORD 'def_app_pw';
  END IF;
END $$;
SQL
# CREATE DATABASE can't run inside a DO block, so guard each one with a shell test.
psql -h db -U postgres -tc "SELECT 1 FROM pg_database WHERE datname='vulnerable_db'" | grep -q 1 \
  || psql -h db -U postgres -c "CREATE DATABASE vulnerable_db"
psql -h db -U postgres -tc "SELECT 1 FROM pg_database WHERE datname='defended_db'" | grep -q 1 \
  || psql -h db -U postgres -c "CREATE DATABASE defended_db OWNER def_owner"
psql -h db -U postgres -d defended_db -c "ALTER SCHEMA public OWNER TO def_owner" >/dev/null

echo "==> Writing .env files"
cat > backend-vulnerable/.env <<EOF
DB_HOST=db
DB_PORT=5432
DB_NAME=vulnerable_db
DB_USER=postgres
DB_PASSWORD=postgres
DB_SSLMODE=prefer
EOF
cat > backend-defended/.env <<EOF
DB_HOST=db
DB_PORT=5432
DB_NAME=defended_db
DB_USER=def_app
DB_PASSWORD=def_app_pw
DB_SSLMODE=prefer
SESSION_SECRET=$(python -c "import secrets;print(secrets.token_hex(32))")
EOF

echo "==> Seeding the vulnerable database"
( cd backend-vulnerable && python init_db.py )

echo "==> Seeding the defended database (schema as owner, users as superuser)"
PGPASSWORD=def_owner_pw psql -h db -U def_owner -d defended_db -v ON_ERROR_STOP=1 -f backend-defended/schema.sql
( cd backend-defended && DB_HOST=db DB_SUPERUSER=postgres DB_SUPERPASS=postgres python seed.py )

echo ""
echo "==> Setup complete.  Start both backends with:   ./scripts/run.sh"
