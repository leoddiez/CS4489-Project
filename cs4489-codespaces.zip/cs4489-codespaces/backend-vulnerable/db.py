import os

import psycopg
from dotenv import load_dotenv

load_dotenv()


def get_connection():
    return psycopg.connect(
        host=os.getenv("DB_HOST"),
        port=os.getenv("DB_PORT", "5432"),
        dbname=os.getenv("DB_NAME"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        # Reads DB_SSLMODE so a local Postgres (no SSL) works with "prefer",
        # while the Azure deployment keeps the original "require" by default.
        sslmode=os.getenv("DB_SSLMODE", "require"),
    )
