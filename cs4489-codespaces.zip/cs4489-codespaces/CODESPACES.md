# Running the CS4489 security demo in GitHub Codespaces

This adds a one-click dev environment that runs **both** backends — the
intentionally vulnerable one and the hardened ("defended") one — against a
local PostgreSQL 16, so the whole vulnerable-vs-defended comparison works
without touching Azure.

## What's included

```
.devcontainer/
  devcontainer.json      # Codespace definition (ports, post-create hook)
  docker-compose.yml     # app container + postgres:16 service
  setup.sh               # installs deps, creates DBs/roles, seeds both schemas
backend-vulnerable/
  db.py                  # drop-in: reads DB_SSLMODE (defaults to "require", so Azure is unchanged)
  .env.example
backend-defended/        # the hardened backend (new)
  main.py                # parameterized SQL, Argon2id, RLS, masking, rate-limit, TOTP MFA
  db.py  schema.sql  seed.py  requirements.txt  .env.example
scripts/
  run.sh                 # starts vulnerable :8001 and defended :8002
  mfa_code.py            # prints an admin's current TOTP code for testing
tests/
  run_tests.py           # 11 attack tests, same request to both backends
  bench.py               # latency / throughput benchmark
```

> The only change to your existing repo is `backend-vulnerable/db.py`
> (it now honours a `DB_SSLMODE` env var; the default stays `require`, so the
> Azure deployment behaves exactly as before). Everything else is additive.

## First run

1. On GitHub, click **Code → Codespaces → Create codespace on main**.
2. Wait for the container to build. `setup.sh` runs automatically: it installs
   dependencies, starts PostgreSQL, creates `vulnerable_db` and `defended_db`
   plus the least-privilege `def_app` role, and seeds both. When it finishes it
   prints the admin **TOTP secrets** — copy them into an authenticator app if
   you want to log in as an admin from the UI.
3. Start both backends:
   ```bash
   ./scripts/run.sh
   ```
4. Open the **Ports** tab. Forwarded: `8001` (vulnerable), `8002` (defended),
   `8080` (frontend). Make a port **Public** if you'll reach it from the browser.

## Try it

```bash
# health
curl localhost:8001/db-health
curl localhost:8002/db-health

# SQL injection bypasses the vulnerable login (note the leaked password):
curl -X POST localhost:8001/auth/login -H 'Content-Type: application/json' \
     -d '{"username":"alice","password":"'"'"' OR '"'"'1'"'"'='"'"'1"}'

# the same payload is rejected by the defended login:
curl -X POST localhost:8002/auth/login -H 'Content-Type: application/json' \
     -d '{"username":"alice","password":"'"'"' OR '"'"'1'"'"'='"'"'1"}'

# admin login needs the second factor:
CODE=$(python scripts/mfa_code.py alphaadmin)
curl -X POST localhost:8002/auth/login -H 'Content-Type: application/json' \
     -d "{\"username\":\"alphaadmin\",\"password\":\"alpha123\",\"totp\":\"$CODE\"}"
```

## Reproduce the report's results

```bash
source .venv/bin/activate
python tests/run_tests.py          # 11/11 security separation table
python tests/bench.py              # latency + throughput

# optional: automated SQL-injection scan
pip install sqlmap
printf 'POST /auth/login HTTP/1.1\nHost: 127.0.0.1:8001\nContent-Type: application/json\n\n{"username":"alice","password":"test"}\n' > /tmp/v.txt
sqlmap -r /tmp/v.txt -p password --batch --level 3 --risk 2 --ignore-code 401   # injectable
# repeat against :8002 -> not injectable
```

## Frontend (optional)

```bash
cd frontend && node server.js      # serves on 8080
```
Point it at a backend by setting `API_BASE_URL` in `login.js` and `dashboard.js`
to the forwarded `:8001`/`:8002` URL from the Ports tab, and add that frontend
origin to the CORS `allow_origins` list in the backend's `main.py`.

## Demo credentials (fake data only)

| User | Password | Tenant | Role | Second factor |
| --- | --- | --- | --- | --- |
| alice | alice123 | Alpha Health | user | none |
| alphaadmin | alpha123 | Alpha Health | admin | TOTP required |
| charlie | charlie123 | Beta Health | user | none |
| betaadmin | beta123 | Beta Health | admin | TOTP required |
