import os
"""
Performance benchmark: vulnerable vs defended backend.

Measures per-request latency (mean / p50 / p95) and throughput for the key
endpoints, under a fixed number of sequential and concurrent requests, so the
cost of the security controls (Argon2 hashing, token verification, RLS, extra
round-trips for audit logging) can be quantified.
"""

import time
import json
import statistics
import asyncio
import httpx

VULN = "http://127.0.0.1:8001"
DEF = "http://127.0.0.1:8002"
N = 200           # sequential samples per measurement
CONC = 30         # concurrency level for throughput test
CONC_TOTAL = 300  # total requests in concurrency test


def pct(values, p):
    k = (len(values) - 1) * p
    f = int(k)
    c = min(f + 1, len(values) - 1)
    if f == c:
        return values[f]
    return values[f] + (values[c] - values[f]) * (k - f)


def summarize(latencies_ms):
    s = sorted(latencies_ms)
    return {
        "n": len(s),
        "mean_ms": round(statistics.mean(s), 2),
        "p50_ms": round(pct(s, 0.50), 2),
        "p95_ms": round(pct(s, 0.95), 2),
        "min_ms": round(s[0], 2),
        "max_ms": round(s[-1], 2),
    }


def seq_measure(method, url, n, **kw):
    lat = []
    with httpx.Client(timeout=30) as c:
        # warmup
        for _ in range(5):
            c.request(method, url, **kw)
        for _ in range(n):
            t0 = time.perf_counter()
            c.request(method, url, **kw)
            lat.append((time.perf_counter() - t0) * 1000)
    return summarize(lat)


async def conc_measure(method, url, total, concurrency, **kw):
    sem = asyncio.Semaphore(concurrency)
    lat = []

    async def one(client):
        async with sem:
            t0 = time.perf_counter()
            await client.request(method, url, **kw)
            lat.append((time.perf_counter() - t0) * 1000)

    async with httpx.AsyncClient(timeout=30) as client:
        t0 = time.perf_counter()
        await asyncio.gather(*[one(client) for _ in range(total)])
        wall = time.perf_counter() - t0
    return summarize(lat), round(total / wall, 1)  # throughput req/s


def get_def_token(user, pw):
    r = httpx.post(f"{DEF}/auth/login", json={"username": user, "password": pw}, timeout=30)
    return r.json()["token"]


def reset_locks():
    import subprocess
    subprocess.run(
        ["psql", "-h", os.getenv("DB_HOST", "db"), "-U", "postgres", "-d", "defended_db",
         "-c", "UPDATE users SET failed_logins=0, locked_until=NULL;"],
        env={"PGPASSWORD": os.getenv("DB_SUPERPASS", "postgres"), "PATH": "/usr/bin:/bin"},
        capture_output=True,
    )


report = {}

# ---- Health endpoint (baseline: framework + DB round-trip, no security work)
report["health_vuln"] = seq_measure("GET", f"{VULN}/db-health", N)
report["health_def"] = seq_measure("GET", f"{DEF}/db-health", N)

# ---- Login (the endpoint where the security cost is concentrated: Argon2) ----
# Vulnerable: plaintext compare. Defended: Argon2id verify + audit insert + token.
report["login_vuln"] = seq_measure(
    "POST", f"{VULN}/auth/login", N,
    json={"username": "alice", "password": "alice123"},
    headers={"Content-Type": "application/json"},
)
reset_locks()
report["login_def"] = seq_measure(
    "POST", f"{DEF}/auth/login", N,
    json={"username": "alice", "password": "alice123"},
    headers={"Content-Type": "application/json"},
)
reset_locks()

# ---- Customer read (vuln: path param; def: token + RLS + masking) ----
report["customers_vuln"] = seq_measure("GET", f"{VULN}/api/customers/1", N)
tok = get_def_token("alphaadmin", "alpha123")
report["customers_def"] = seq_measure(
    "GET", f"{DEF}/api/customers", N, headers={"Authorization": f"Bearer {tok}"}
)

# ---- Concurrency / throughput on customer read ----
loop = asyncio.new_event_loop()
csum_v, cthr_v = loop.run_until_complete(
    conc_measure("GET", f"{VULN}/api/customers/1", CONC_TOTAL, CONC)
)
csum_d, cthr_d = loop.run_until_complete(
    conc_measure("GET", f"{DEF}/api/customers", CONC_TOTAL, CONC,
                 headers={"Authorization": f"Bearer {tok}"})
)
loop.close()
report["customers_conc_vuln"] = {**csum_v, "throughput_rps": cthr_v}
report["customers_conc_def"] = {**csum_d, "throughput_rps": cthr_d}

with open("/home/claude/run/perf/perf_results.json", "w") as f:
    json.dump(report, f, indent=2)

# print table
def line(label, v, d, key):
    print(f"{label:34} {v[key]:>10} {d[key]:>10}")

print(f"\n{'Metric':34} {'Vulnerable':>10} {'Defended':>10}")
print("-" * 56)
print("LOGIN  (Argon2 is the cost driver)")
for k in ("mean_ms", "p50_ms", "p95_ms"):
    line("  login " + k, report["login_vuln"], report["login_def"], k)
print("DB-HEALTH (baseline framework+DB)")
for k in ("mean_ms", "p50_ms", "p95_ms"):
    line("  health " + k, report["health_vuln"], report["health_def"], k)
print("CUSTOMER READ (sequential)")
for k in ("mean_ms", "p50_ms", "p95_ms"):
    line("  read " + k, report["customers_vuln"], report["customers_def"], k)
print("CUSTOMER READ (concurrency=%d)" % CONC)
for k in ("mean_ms", "p95_ms", "throughput_rps"):
    line("  read " + k, report["customers_conc_vuln"], report["customers_conc_def"], k)
