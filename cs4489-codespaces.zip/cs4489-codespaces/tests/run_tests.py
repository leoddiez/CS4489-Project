"""
Comparative security test harness for the CS4489 project.

Sends the SAME requests to the vulnerable backend (:8001) and the defended
backend (:8002) and records, for each test, whether the application was
exploited (INSECURE) or the attack was prevented (SECURE).

No destructive payloads: injection strings are standard authentication-bypass
and boolean test vectors used to confirm whether input reaches the SQL parser.
"""

import json
import httpx

VULN = "http://127.0.0.1:8001"
DEF = "http://127.0.0.1:8002"

results = []


def rec(name, target, outcome, evidence):
    results.append({"test": name, "target": target, "outcome": outcome, "evidence": evidence})


def login(base, username, password):
    r = httpx.post(f"{base}/auth/login", json={"username": username, "password": password}, timeout=20)
    return r


def get_token(base, username, password):
    r = login(base, username, password)
    if r.status_code == 200:
        return r.json().get("token")
    return None


# ---------------------------------------------------------------------------
# T1. SQL injection authentication bypass
# ---------------------------------------------------------------------------
def t1_sqli_bypass(base, label):
    # Classic tautology in the password field.
    payload = {"username": "alice", "password": "' OR '1'='1"}
    r = httpx.post(f"{base}/auth/login", json=payload, timeout=20)
    bypassed = r.status_code == 200 and r.json().get("message") == "Login successful"
    rec("T1 SQLi auth bypass (password tautology)", label,
        "INSECURE" if bypassed else "SECURE",
        f"HTTP {r.status_code}; bypass={'yes' if bypassed else 'no'}")
    return bypassed


# ---------------------------------------------------------------------------
# T2. SQL injection to read another tenant's / admin account via UNION-free OR
# ---------------------------------------------------------------------------
def t2_sqli_any_user(base, label):
    # Inject an OR clause in the password field to extract the admin account
    # without knowing its password.
    payload = {"username": "alice", "password": "' OR username='alphaadmin"}
    r = httpx.post(f"{base}/auth/login", json=payload, timeout=20)
    leaked_admin = False
    if r.status_code == 200:
        body = r.json()
        leaked_admin = body.get("role") == "admin" and body.get("username") == "alphaadmin"
    rec("T2 SQLi returns admin row without password", label,
        "INSECURE" if leaked_admin else "SECURE",
        f"HTTP {r.status_code}; admin_row_returned={'yes' if leaked_admin else 'no'}")
    return leaked_admin


# ---------------------------------------------------------------------------
# T3. Username enumeration (different error for valid vs invalid user)
# ---------------------------------------------------------------------------
def t3_user_enum(base, label):
    r_valid = login(base, "alice", "wrongpassword")
    r_invalid = login(base, "no_such_user_zzz", "wrongpassword")
    v = (r_valid.status_code, _detail(r_valid))
    i = (r_invalid.status_code, _detail(r_invalid))
    distinguishable = v != i
    rec("T3 Username enumeration", label,
        "INSECURE" if distinguishable else "SECURE",
        f"valid-user={v}  invalid-user={i}  distinguishable={'yes' if distinguishable else 'no'}")
    return distinguishable


# ---------------------------------------------------------------------------
# T4. Sensitive data exposure in login response (password returned)
# ---------------------------------------------------------------------------
def t4_password_leak(base, label):
    r = login(base, "alice", "alice123")
    leaked = r.status_code == 200 and "password" in r.json()
    rec("T4 Password/credential leak in response", label,
        "INSECURE" if leaked else "SECURE",
        f"keys={sorted(r.json().keys()) if r.status_code==200 else r.status_code}")
    return leaked


# ---------------------------------------------------------------------------
# T5. Verbose DB error disclosure (trigger a type error)
# ---------------------------------------------------------------------------
def t5_error_disclosure(base, label):
    # A quote imbalance causes a SQL syntax error on the vulnerable build.
    payload = {"username": "alice'", "password": "x"}
    r = httpx.post(f"{base}/auth/login", json=payload, timeout=20)
    body = r.text.lower()
    leaked = any(k in body for k in [
        "syntax error", "unterminated quoted", "psycopg", "postgresql",
        "line 4", "where username", "at or near", "database_error",
    ])
    rec("T5 Verbose database error disclosure", label,
        "INSECURE" if leaked else "SECURE",
        f"HTTP {r.status_code}; db_internals_in_body={'yes' if leaked else 'no'}")
    return leaked


# ---------------------------------------------------------------------------
# T6. Broken object-level / tenant authorization (BOLA / IDOR)
#     Can a tenant-1 session read tenant-2 customer data?
# ---------------------------------------------------------------------------
def t6_cross_tenant_read(base, label):
    if label == "VULNERABLE":
        # No auth required; tenant id is a path param the client chooses.
        r1 = httpx.get(f"{base}/api/customers/1", timeout=20)
        r2 = httpx.get(f"{base}/api/customers/2", timeout=20)
        got_both = (r1.status_code == 200 and r2.status_code == 200
                    and len(r1.json().get("customers", [])) > 0
                    and len(r2.json().get("customers", [])) > 0)
        rec("T6 Cross-tenant data access (BOLA)", label,
            "INSECURE" if got_both else "SECURE",
            f"tenant1_rows={len(r1.json().get('customers',[]))} "
            f"tenant2_rows={len(r2.json().get('customers',[]))} (no auth needed)")
        return got_both
    else:
        # Defended: tenant comes from the token. Log in as Alpha (tenant 1),
        # then try to see Beta data. The endpoint has no tenant parameter,
        # so the only data returned must be tenant 1.
        tok = get_token(base, "alice", "alice123")
        r = httpx.get(f"{base}/api/customers", headers={"Authorization": f"Bearer {tok}"}, timeout=20)
        rows = r.json().get("customers", []) if r.status_code == 200 else []
        # Any Beta row (Charlie/Diana) would be a cross-tenant leak.
        beta_leak = any(c["full_name"] in ("Charlie Lee", "Diana Brown") for c in rows)
        rec("T6 Cross-tenant data access (BOLA)", label,
            "INSECURE" if beta_leak else "SECURE",
            f"rows_returned={len(rows)} beta_rows_leaked={'yes' if beta_leak else 'no'} (tenant from token)")
        return beta_leak


# ---------------------------------------------------------------------------
# T7. Missing authentication on sensitive endpoints
# ---------------------------------------------------------------------------
def t7_missing_auth(base, label):
    # Admin tenant report with no credentials.
    r = httpx.get(f"{base}/api/admin/tenant-report", timeout=20)
    open_access = r.status_code == 200
    rec("T7 Unauthenticated access to admin report", label,
        "INSECURE" if open_access else "SECURE",
        f"HTTP {r.status_code} without any token")
    return open_access


# ---------------------------------------------------------------------------
# T8. Plaintext password storage (inspect what the app persists/returns)
# ---------------------------------------------------------------------------
def t8_plaintext_storage(base, label):
    r = login(base, "alice", "alice123")
    if r.status_code != 200:
        rec("T8 Plaintext password storage", label, "SECURE", "no password field returned")
        return False
    pw = r.json().get("password")
    plaintext = pw == "alice123"
    rec("T8 Plaintext password storage", label,
        "INSECURE" if plaintext else "SECURE",
        "login response exposes stored plaintext password" if plaintext
        else "no plaintext password exposed")
    return plaintext


# ---------------------------------------------------------------------------
# T9. Sensitive field masking (SSN last-4) for non-admin
# ---------------------------------------------------------------------------
def t9_masking(base, label):
    if label == "VULNERABLE":
        r = httpx.get(f"{base}/api/customers/1", timeout=20)
        rows = r.json().get("customers", [])
        exposed = any(c.get("ssn_last4") not in (None, "", "****") for c in rows)
        rec("T9 Sensitive field (SSN) masking for non-admin", label,
            "INSECURE" if exposed else "SECURE",
            f"ssn values visible to any caller: {[c.get('ssn_last4') for c in rows]}")
        return exposed
    else:
        tok = get_token(base, "alice", "alice123")  # non-admin
        r = httpx.get(f"{base}/api/customers", headers={"Authorization": f"Bearer {tok}"}, timeout=20)
        rows = r.json().get("customers", [])
        exposed = any(c.get("ssn_last4") not in (None, "", "****") for c in rows)
        rec("T9 Sensitive field (SSN) masking for non-admin", label,
            "INSECURE" if exposed else "SECURE",
            f"non-admin sees ssn values: {[c.get('ssn_last4') for c in rows]}")
        return exposed


# ---------------------------------------------------------------------------
# T10. Rate limiting / brute-force resistance on login
# ---------------------------------------------------------------------------
def t10_rate_limit(base, label):
    codes = []
    for _ in range(15):
        r = login(base, "bruteforce_probe", "x")
        codes.append(r.status_code)
    throttled = 429 in codes
    rec("T10 Login brute-force rate limiting", label,
        "SECURE" if throttled else "INSECURE",
        f"status codes over 15 rapid attempts: {_summarize(codes)}; throttled={'yes' if throttled else 'no'}")
    return throttled


def _detail(r):
    try:
        d = r.json().get("detail")
        return d if isinstance(d, str) else type(d).__name__
    except Exception:
        return r.text[:40]


def _summarize(codes):
    from collections import Counter
    return dict(Counter(codes))


def run(base, label):
    t1_sqli_bypass(base, label)
    t2_sqli_any_user(base, label)
    t3_user_enum(base, label)
    t4_password_leak(base, label)
    t5_error_disclosure(base, label)
    t6_cross_tenant_read(base, label)
    t7_missing_auth(base, label)
    t8_plaintext_storage(base, label)
    t9_masking(base, label)
    t10_rate_limit(base, label)


if __name__ == "__main__":
    run(VULN, "VULNERABLE")
    run(DEF, "DEFENDED")
    with open("/home/claude/run/sectests/results.json", "w") as f:
        json.dump(results, f, indent=2)

    # Pretty table
    tests = []
    seen = []
    for r in results:
        if r["test"] not in seen:
            seen.append(r["test"])
    print(f"{'Test':52} {'Vulnerable':12} {'Defended':12}")
    print("-" * 78)
    for t in seen:
        v = next((r for r in results if r["test"] == t and r["target"] == "VULNERABLE"), None)
        d = next((r for r in results if r["test"] == t and r["target"] == "DEFENDED"), None)
        print(f"{t:52} {v['outcome'] if v else '-':12} {d['outcome'] if d else '-':12}")
